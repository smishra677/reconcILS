import os

import sys
sys.path.append("../../")
sys.path.append("../")
import tracemalloc
from reconcILS import *
from utils_reconcILS import *
import pandas as pd     
import timeit
from ete3 import PhyloTree
from collections import Counter



dic={'Process':[],'Replicate':[],'Gene_tree':[],'Species_Tree':[],'Duplication':[],'NNI':[],'DLCILS':[],'Loss':[],'Hemiplasy':[],'RHemiplasy':[]}
    

def convert(df,df1):
	df['Loss'].append(sum(list(df1['loss'])))
	df['DLCILS'].append(sum(list(df1['coal'])))
	df['Duplication'].append(sum(list(df1['dup'])))
	df['Hemiplasy'].append(0)
	df['NNI'].append(0)
	df['RHemiplasy'].append(0)
	
	return df

def put_it_in_sp(df,node_to_leaves):
    events={}
    for idx, row in df.iterrows():

        if int(row['parentid'])==-1:
            if row['nodeid'].isnumeric():
                start= repr(list(sorted(node_to_leaves[str(row['nodeid'])])))
            else:
                start =repr(list({row['nodeid']}))
        
        else:
            start=repr(list(sorted(node_to_leaves[str(row['parentid'])])))
        end=''


        if row['nodeid'].isnumeric():
            end= repr(list(sorted(node_to_leaves[str(row['nodeid'])])))
        else:
            end =repr(list({row['nodeid']}))
        


        events[(start,'to',end)]= {'D':row['dup'],'I':row['coal'],'L':row['loss']}


    return events


def read_trees(i,folder):
        gene_tre= open(folder+'/rep_'+str(i)+'.tre')
        tr =gene_tre.read().strip().split('\n')
        gene_tre.close()
        return str(tr[0])

def write_trees(i,folder,tree):
        with open(folder+'/rep_1_'+str(i)+'.tre', 'w') as f:
            f.write(tree)
        


sp_string='(A,(B,C));'
#sp_string='(B,C);'




def find_leaves(node, df):
    if not node.isnumeric():
        return node


    children = df[df['parentid'] == int(node)]['nodeid'].tolist()

    if not children:
        return {node}
    else:
        result = set()
        for child in children:
            result.update(find_leaves(child, df))
        return result



gene_folder='./10_01'


#gene_tre= open('./output_gene/gene_tree.txt')
#trees =gene_tre.read().strip().split('\n')
#gene_tre.close()


value=0
previous_dict={}
erro=0
fil= open(gene_folder+'_error.txt','w+')
#sp ='(((A,B),C),D);'
dlcparTime=[]
reconcILSTime_iterative=[]
reconcILSTime_recurssive=[]
ete_time=[]
ete_mem=[]
reconcILS_mem=[]
li_gt=[]
lis_rep=[]
red= readWrite.readWrite()
reco =reconcils()
sp_large=red.parse(sp_string)
sp_large.label_internal()
species_edge_list=reco.get_edges(sp_large)
for i in range(1000):
            reco =reconcils()
            sp=red.parse(sp_string)
            if erro==1:
                dic=previous_dict

            previous_dict=dic

            DATA_PATH = "./"
            file_path = os.path.join(DATA_PATH)

    
            try:
                tree= str(read_trees(i,os.path.join(file_path, gene_folder)))
                tr=red.parse(tree)
                print(tr.to_newick())
                print(i)
                write_trees(i,os.path.join(file_path, gene_folder),tr.to_newick())

                try:
                    starttime = timeit.default_timer()
                    
                    

                    command1= 'python2 ./dlcpar dp -D 1.1 -L 1.0 -C 1.0 -K 1.0 -s ./sp_tree.tre -S ./001.mapsl  ./'+gene_folder+'/rep_1_'+str(i)+'.tre'
                    command2= 'python2 ./dlcpar events --lct -s ./sp_tree.tre -S ./001.mapsl ./'+gene_folder+'/rep_1_'+str(i)+'.tre.dlcdp.lct.tree > result_data'
                    os.system(command1)
                    os.system(command2)
 
                    dlcparTime.append(timeit.default_timer()-starttime)
                    df = pd.read_csv('result_data',header=0, delimiter='\t')
                    parent_ids = list(df['parentid'].values)
                    parent_ids = [str(ije) for ije in parent_ids]

            
                    node_to_leaves = {row['nodeid']: find_leaves(row['nodeid'], df) for index, row in df.iterrows() if row['nodeid'] in parent_ids}
                    
                    dic_dlc=put_it_in_sp(df,node_to_leaves)
                    

                    dic['Gene_tree']+=[tree]
                    dic['Species_Tree']+=[sp_string]
                    dic= red.read_log('True Process',i,dic,gene_folder)
                    lis_rep.append(i)
                    li_gt.append(tr.to_newick())



                    
                    dic['Process'].append('DLCpar')
                    dic['Replicate'].append(str(i))
                    dic['Gene_tree'].append(tr.to_newick())
                    dic['Species_Tree'].append(sp_string)
                    dic=convert(dic,df)


                
                

                    tracemalloc.start()
                    genetree = PhyloTree(tr.to_newick())
                    
                    sptree = PhyloTree(sp_string)
        
                    
                    starttime = timeit.default_timer()
                    recon_tree_ete, events = genetree.reconcile(sptree)
                    current, peak = tracemalloc.get_traced_memory()
                    ete_mem.append(peak / 10**6)
                    tracemalloc.stop()
                    ete_time.append(timeit.default_timer()-starttime)
                    dic['Gene_tree']+=[tr.to_newick()]
                    dic['Species_Tree']+=[sp_string]

                    fr={}
                                        


                    fr = red.label_ete3(recon_tree_ete,fr)

                
                    dic= red.Create_pd_ete3('ETE3',i,dict(Counter(red.sp_event_ete3(recon_tree_ete,events))),dic)

                

            

                    #try:
                    tracemalloc.start()
                    sp_copy= copy.deepcopy(sp)
                    sp_copy.reset()
                    reco.gene_tree=copy.deepcopy(tr)

                    tr.order_gene(sp)

                    tr.label_internal()
                    sp.label_internal()



                    tr.map_gene(sp)
                    reco.setCost(sp)

                    sp.isRoot=True
                    tr.isRoot=True
                    sp_copy.isRoot=True

                    starttime1 = timeit.default_timer()
                    li=reco.iterative_reconcILS(tr,sp,sp_copy,sp,[])

                    reconcILSTime_iterative.append(timeit.default_timer()-starttime1)

                    fr = red.find_replacement_for_edge(species_edge_list,fr)
                    dic_reconcILS=red.label_reconcILS(li)
                    dic_reconcILS,fr,eve_rec,eve_ete=red.put_it_in_sp_tree(species_edge_list,dic_reconcILS,fr)

                                                
                                                        


                    reco.edge_to_event(sp_large,dic_reconcILS,0) 
                    reco.edge_to_event(sp_large,fr,1)
                    current, peak = tracemalloc.get_traced_memory()
                    reconcILS_mem.append(peak / 10**6)
                    tracemalloc.stop()


            
                    dic['Gene_tree']+=[red.to_newick(reco.gene_tree)]
                    dic['Species_Tree']+=[red.to_newick_sp(sp_large)]
                    dic['DLCILS']+=[0]
                    dic['Hemiplasy']+=[0]
                    dic['RHemiplasy']+=[0]
                    #li =red.sp_event(sp,[])


                    dic= red.Create_pd('reconcILS',i,li,dic)

                    df = pd.DataFrame(dic)





                    df.to_csv(gene_folder+'_1_result.csv', index=False)
                    time_dic={'reconcILSTime_iterative':reconcILSTime_iterative,'ete_time':ete_time}
                    df = pd.DataFrame(time_dic)





                    df.to_csv(gene_folder+'_1_time.csv', index=False)

                    mem_dic={'reconcILSTime_iterative':reconcILS_mem,'ete_time':ete_mem}
                    df = pd.DataFrame(mem_dic)





                    df.to_csv(gene_folder+'_1_mem.csv', index=False)
                    print(df)
                except:
                        
                    erro=1
                    dic=previous_dict
                    print(i)
                    
                    #li_gt=li_gt[:-1]
                    #lis_rep=lis_rep[:-1]
                    fil.write("ete3/reconcILS "+tree+"   "+str(i)+'\n')
                    print(tr.to_newick())
                    continue
            except:
                    erro=1
                    dic=previous_dict
                    print(i)
                    
                    #li_gt=li_gt[:-1]
                    #lis_rep=lis_rep[:-1]
                    fil.write("empty "+tree+"   "+str(i)+'\n')
                    print(tr.to_newick())
                    continue

        
            
if erro==1:
    dic=previous_dict
for i in dic:
    print(len(dic[i]))
    
print(dic)
df = pd.DataFrame(dic)
print(df)
print(len(lis_rep),len(li_gt))
time_dic={'Replicate':lis_rep,'Gene_tree':li_gt,'reconcILSTime_iterative':reconcILSTime_iterative,'dlcparTime':dlcparTime,'ete_time':ete_time}
print(time_dic)
print(len(reconcILSTime_iterative))
print(len(reconcILSTime_recurssive))

print(len(dlcparTime))
df1 = pd.DataFrame(time_dic)



df.to_csv(gene_folder+'_1_result.csv', index=False)

df1.to_csv(gene_folder+'_1_time_result.csv', index=False)


        


        


   