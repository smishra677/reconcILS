import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from scipy.stats import spearmanr
from sklearn.metrics import r2_score


x=[0,99.9,86.8,72.2,46.1,51,26.8,29.3,41.8,87.3,83,39.5,70.6,36,52.6,51.8,99.2,99.5,47.4,65.6,95.9,60.3,55.2,55.3,62.8,55.1,55.7,87.1,82,72.9,40.8,34.5,43.8,78,61.7,49,52.3,55.1,56.4]

y=[0,99.8,87.8,71.7,49.5,49,28.9,29.6,44.4,86.5,84.6,40.9,72.1,39.9,57.5,54,98.4,99.9,44.5,66.4,96.8,59.9,52.8,55.5,60.6,54.8,55.6,89.1,82.7,73.9,39.7,33.3,44,78.8,63.7,45.4,46.6,57.2,55.4]



df = pd.DataFrame({'X': x, 'Y': y})

sns.set(style="whitegrid")
plt.figure(figsize=(10, 6))
sns.regplot(x='X', y='Y', data=df, scatter_kws={'s': 50}, line_kws={'color': 'red'})


plt.title('Correlation between  SimPhy gcf and reconcILS gcf')
plt.xlabel('SimPhy gcf ')
plt.ylabel('reconcILS gcf')


spearman_correlation, P = spearmanr(x, y)

r2 = r2_score(x, y)

print('spearman_correlation',spearman_correlation,P)
print('R2',r2)

correlation_coefficient = df.corr().iloc[0, 1]

plt.text(1, 1, f'Correlation: {correlation_coefficient:.2f} spearmanr: {spearman_correlation:.2f} r2_score: {r2:.2f}', fontsize=12, color='blue', bbox=dict(facecolor='white', alpha=0.5))

plt.show()




