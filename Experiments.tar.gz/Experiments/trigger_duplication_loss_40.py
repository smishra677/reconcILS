import os
import tracemalloc
import timeit
import sys
sys.path.append("../../")
sys.path.append("../")
from reconcILS import *
from utils_reconcILS import *
import pandas as pd     
from ete3 import PhyloTree
from collections import Counter



# Folder location
simphy_location='./Data_40_with_duplication_loss/SimPhy_outfiles_40_0.003_0.003'
dupcoal_location='./Data_40_with_duplication_loss/dupcoal_40_0.03_0.03'

dic={'Process':[],'Replicate':[],'Gene_tree':[],'Species_Tree':[],'Duplication':[],'NNI':[],'DLCILS':[],'Loss':[],'Hemiplasy':[],'RHemiplasy':[]}
dic_simphy={'Process':[],'Replicate':[],'Gene_tree':[],'Species_Tree':[],'Duplication':[],'NNI':[],'Loss':[]}


    





def read_trees(i,folder):
        gene_tre= open(folder+'/rep_'+str(i)+'.tre')
        tr =gene_tre.read().strip().split('\n')
        gene_tre.close()
        return str(tr[0])

def write_trees(i,folder,tree):
        with open(folder+'/rep_1_'+str(i)+'.tre', 'w') as f:
            f.write(tree)
        


#sp_string='(((A:0.3,(B:0.2,C:0.2):0.1):0.5,D:0.8):1.5,((E:1.0,F:1.0):1.3,(G:1.0,H:1.0):1.3):0.0);'
sp_string='((((M,(AF,B)),(P,(AJ,(AE,(O,D))))),((W,AH),((AN,N),((X,AG),(R,E))))),((H,(Y,AB)),((((L,V),(AC,A)),((C,Z),(F,K))),(((AM,AA),(AL,(T,(U,AI)))),((S,(G,AD)),((Q,J),(I,AK)))))));'
#sp_string='(A,(B,C));'




                



def read_log_simphy(dic,replicate_):
    import sqlite3
    conn = sqlite3.connect(simphy_location+'/SimPhy_outfiles.db')

    conn.row_factory = sqlite3.Row

    cursor = conn.cursor()

    query = "SELECT * FROM Locus_Trees"

    cursor.execute(query)

    rows = cursor.fetchall()
    dic_simphy['Process']+=['True Simphy']
    dic_simphy['Replicate']+=[replicate_]


    dic_simphy['Duplication']+=[rows[replicate_]['n_dup']]
    dic_simphy['Loss']+=[rows[replicate_]['n_loss']]





    cursor.close()

    conn.row_factory = sqlite3.Row

    cursor = conn.cursor()

    query = "SELECT * FROM Gene_Trees"

    cursor.execute(query)

    rows = cursor.fetchall()


    dic_simphy['NNI']+=[rows[replicate_]['Extra_l']]


    cursor.close()
    conn.close()
    return dic_simphy




red= readWrite.readWrite()
reco =reconcils()


value=0
previous_dict={}
erro=0
fil= open('1_error.txt','w+')

dlcparTime=[]
reconcILSTime_iterative=[]
reconcILSTime_iterative_simphy=[]
reconcILSTime_recurssive=[]
ete_time=[]
ete_time_simphy=[]
ete_mem=[]
reconcILS_mem=[]
li_gt=[]
lis_rep=[]

sp_large=red.parse_bio(sp_string)
sp_large_simphy=red.parse_bio(sp_string)
sp_str_ref=sp_large.to_newick()



sp_large=sp_large.parse(sp_str_ref)
sp_large.label_internal()


species_edge_list=reco.get_edges(sp_large)
sp_large_simphy=sp_large_simphy.parse(sp_str_ref)
sp_large_simphy.label_internal()

sp_large_simphy=sp_large_simphy.parse(sp_str_ref)
sp_large_simphy.label_internal()



for replicate_ in range(1000):
                        print(replicate_)

                        sp=red.parse(sp_string)
                        if erro==1:
                            dic=previous_dict

                        previous_dict=dic

                        DATA_PATH = "./"
                        file_path = os.path.join(DATA_PATH)
                        for path_ in range(2):

                            if path_ ==0:
                                    #try:

                                    tree= str(open(simphy_location+'/1/g_trees'+str(replicate_+1).zfill(4)+'.trees').read())
                                    tree= tree.replace('e-', '0')
                                    tr=red.parse(tree)
                                    dic_simphy['Gene_tree']+=[tr.to_newick()]
                                    dic_simphy['Species_Tree']+=[sp.to_newick()]
                                    dic_simphy= read_log_simphy(dic_simphy,replicate_)

                                    lis_rep.append(replicate_)
                                    li_gt.append(tr.to_newick())
                                    dic_simphy['Gene_tree']+=[tr.to_newick()]
                                    dic_simphy['Species_Tree']+=[sp_string]
                                    print(tr.to_newick())
                                    print(replicate_)
                                    write_trees(replicate_,os.path.join('./', simphy_location+'/1/'),tr.to_newick())
                                    sp_large_simphy_small=sp_large_simphy.parse(sp_str_ref)
                                    sp_large_simphy_small.label_internal()
                                    
                                    '''
                                    
                                    command1= 'python2 ./dlcpar dp -D 1.1 -L 1.0 -C 1.0 -K 1.0 -s ./sp_tree.tre -S ./001.mapsl  '+simphy_location+'/1/rep_1_'+str(replicate_)+'.tre'
                                    command2= 'python2 ./dlcpar events --lct -s ./sp_tree.tre -S ./001.mapsl '+simphy_location+'/1/rep_1_'+str(replicate_)+'.tre.dlcdp.lct.tree > result_data'
                                    os.system(command1)
                                    os.system(command2)
                                    
                                    df = pd.read_csv('result_data',header=0, delimiter='\t')
                                    parent_ids = list(df['parentid'].values)
                                    parent_ids = [str(ije) for ije in parent_ids]

                             
                                    node_to_leaves = {row['nodeid']: find_leaves(row['nodeid'], df) for index, row in df.iterrows() if row['nodeid'] in parent_ids}
                                    
                                    dic_dlc=put_it_in_sp(df,node_to_leaves,species_edge_list)




                                    

                                    
                                    dic_simphy['Process'].append('DLCpar')
                                    dic_simphy['Replicate'].append(str(replicate_))
                                    dic_simphy['Gene_tree'].append(tr.to_newick())
                                    dic_simphy['Species_Tree'].append(sp_string)
                                    dic_simphy=convert_1(dic_simphy,df)

                                    '''

                                    tracemalloc.start()
                                    genetree = PhyloTree(tr.to_newick())
                                    
                                    sptree = PhyloTree(sp_string)
                        
                                    #tracemalloc.start()
                                    starttime = timeit.default_timer()
                                    recon_tree, events = genetree.reconcile(sptree)
                                    current, peak = tracemalloc.get_traced_memory()



                                    ete_mem.append(peak / 10**6)
                                    tracemalloc.stop()

                                    ete_time_simphy.append(timeit.default_timer()-starttime)

                                    #print(recon_tree.show())
                                    dic_simphy= red.Create_pd_ete3_1('ETE3',replicate_,dict(Counter(red.sp_event_ete3(recon_tree,events))),dic_simphy)
                                    
                                    fr={}
                                    print(dic_simphy)
                                    #print(recon_tree.show())



                                    fr = red.label_ete3(recon_tree,fr)



                    

                                    #try:
                                    tracemalloc.start()
                                    sp_copy= copy.deepcopy(sp)
                                    sp_copy.reset()
                                    reco.gene_tree=copy.deepcopy(tr)

                                    tr.order_gene(sp)

                                    tr.label_internal()
                                    sp.label_internal()



                                    tr.map_gene(sp)
                                    reco.setCost(sp)

                                    sp.isRoot=True
                                    tr.isRoot=True
                                    sp_copy.isRoot=True
                                    
                                    starttime1 = timeit.default_timer()
                                    li=reco.iterative_reconcILS(tr,sp,sp_copy,sp,[])
                                    current, peak = tracemalloc.get_traced_memory()
                                    
                                    reconcILS_mem.append(peak / 10**6)
                                    tracemalloc.stop()

                                    reconcILSTime_iterative_simphy.append(timeit.default_timer()-starttime1)
                                    print(111111111111111111111111111111111111111111)
                                    dic_simphy['Gene_tree']+=[red.to_newick(reco.gene_tree)]
                                    
                                    #li =red.sp_event(sp,[])
                                    if len(li)==0:

                                        continue
                                    else:   
                                        print('##############################################################################################')
                                        dic_reconcILS=red.label_reconcILS(li)

                                        print('##############################################################################################')

                                        fr = red.find_replacement_for_edge(species_edge_list,fr)
                                        dic_reconcILS,fr,eve_rec,eve_ete=red.put_it_in_sp_tree(species_edge_list,dic_reconcILS,fr)

                                        
                                                
                                                

                                        #sp=sp.parse(sp_str_ref)
                                        #sp.label_internal()

                                        reco.edge_to_event(sp_large_simphy,dic_reconcILS,0) 
                                        reco.edge_to_event(sp_large_simphy,fr,1)

                                        #reco.edge_to_event(sp_large_simphy,dic_dlc,2)



                                        reco.edge_to_event(sp_large_simphy_small,dic_reconcILS,0) 
                                        reco.edge_to_event(sp_large_simphy_small,fr,1)


                                        dic_simphy['Species_Tree']+=[red.to_newick_sp(sp_large_simphy_small)]

                                        if eve_ete['L']!= dic_simphy['Loss'][-1]:
                                                print('Loss Not matching simphy',replicate_,eve_ete['L'], dic_simphy['Loss'][-1])
                                                exit()
                                        if eve_ete['D']!= dic_simphy['Duplication'][-1]:
                                                print('Duplication Not matching simphy',replicate_,eve_ete['D'], dic_simphy['Duplication'][-1])
                                                exit()



                                


                                        dic_simphy= red.Create_pd('reconcILS',replicate_,li,dic_simphy)
                                        print(dic_simphy)
                                        df = pd.DataFrame(dic_simphy)
                                        df.to_csv(simphy_location+'_simphy_1_result.csv', index=False)
                                        oer= open(simphy_location+'_labeled_sp_simphy.csv','w+')
                                        oer.write(red.to_newick_sp(sp_large_simphy))
                                        oer.close()

                                        time_dic={'reconcILSTime_iterative':reconcILSTime_iterative_simphy,'ete_time':ete_time_simphy}
                                       

                                        df_time = pd.DataFrame(time_dic)




                                      
                                        df_time.to_csv(simphy_location+'_1_time_result.csv', index=False)

                                        mem_dic={'reconcILS_mem':reconcILS_mem,'ete_mem':ete_mem}
                                        print(mem_dic)
                                        dem_df  =pd.DataFrame(mem_dic)
                                        dem_df.to_csv(dupcoal_location+'_memory_result_with_dups_loss.csv', index=False)


                                    #except:
                                    #continue

                            else:
                                try:

                                    li_gt=[]
                                    lis_rep=[]
                                    sp=red.parse(sp_string)
                                    tree= str(read_trees(replicate_,os.path.join(file_path, dupcoal_location)))
                                    tree  = tree.replace('e-', '0')
                                    tr=red.parse(tree)
                                    dic= red.read_log('True Process',replicate_,dic,dupcoal_location)
                                    lis_rep.append(replicate_)
                                    li_gt.append(tr.to_newick())
                                    dic['Gene_tree']+=[tr.to_newick()]
                                    dic['Species_Tree']+=[sp_string]
                                    print(tr.to_newick())
                                    print(replicate_)
                                    write_trees(replicate_,os.path.join(file_path, dupcoal_location),tr.to_newick())
                                    sp_large_small=sp_large.parse(sp_str_ref)
                                    sp_large_small.label_internal()

                                    starttime = timeit.default_timer()

                                    tracemalloc.start()
                                
                                    genetree = PhyloTree(tr.to_newick())
                                    
                                    sptree = PhyloTree(sp_string)
                        
                                    
                                    
                                    recon_tree, events = genetree.reconcile(sptree)
                                    current, peak = tracemalloc.get_traced_memory()
                                    ete_mem.append(peak / 10**6)
                                    tracemalloc.stop()
                                    ete_time.append(timeit.default_timer()-starttime)
                                    dic['Gene_tree']+=[tr.to_newick()]
                                    dic['Species_Tree']+=[sp_string]

                                
                                    dic= red.Create_pd_ete3('ETE3',replicate_,dict(Counter(red.sp_event_ete3(recon_tree,events))),dic)

                                    fr={}
                                    fr = red.label_ete3(recon_tree,fr)


                    

                                    #try:
                                    tracemalloc.start()
                                    sp_copy= copy.deepcopy(sp)
                                    sp_copy.reset()
                                    reco.gene_tree=copy.deepcopy(tr)

                                    tr.order_gene(sp)

                                    tr.label_internal()
                                    sp.label_internal()



                                    tr.map_gene(sp)
                                    reco.setCost(sp)

                                    sp.isRoot=True
                                    tr.isRoot=True
                                    sp_copy.isRoot=True

                                    
                                    
                                    starttime1 = timeit.default_timer()
                                    li=reco.iterative_reconcILS(tr,sp,sp_copy,sp,[])
                                    current, peak = tracemalloc.get_traced_memory()
                                    reconcILS_mem.append(peak / 10**6)
                                    tracemalloc.stop()
                                    reconcILSTime_iterative.append(timeit.default_timer()-starttime1)
                                    print(111111111111111111111111111111111111111111)
                                    dic['Gene_tree']+=[red.to_newick(reco.gene_tree)]
                                    
                                    dic['DLCILS']+=[0]
                                    dic['Hemiplasy']+=[0]
                                    dic['RHemiplasy']+=[0]
                                    #li =red.sp_event(sp,[])
                                    if len(li)==0:

                                        continue
                                    else:   
                                        print('##############################################################################################')
                                        dic_reconcILS=red.label_reconcILS(li)
                                        print('##############################################################################################')


                                        fr = red.find_replacement_for_edge(species_edge_list,fr)
                                        dic_reconcILS,fr,eve_rec,eve_ete=red.put_it_in_sp_tree(species_edge_list,dic_reconcILS,fr)

                                        #sp=sp.parse(sp_str_ref)
                                        #sp.label_internal()

                                        reco.edge_to_event(sp_large,dic_reconcILS,0) 
                                        reco.edge_to_event(sp_large,fr,1)
                                                                                
                                                                                
                                        reco.edge_to_event(sp_large_small,dic_reconcILS,0) 
                                        reco.edge_to_event(sp_large_small,fr,1)
                                        
                                        dic['Species_Tree']+=[red.to_newick_sp(sp_large_small)]



                                        if eve_ete['L']!= dic['Loss'][-1]:
                                                print('Loss Not matching dupcoal',replicate_,eve_ete['L'], dic['Loss'][-1])
                                                exit()
                                        if eve_ete['D']!= dic['Duplication'][-1]:
                                                print('Duplication Not matching dupcoal',replicate_,eve_ete['D'], dic['Duplication'][-1])
                                                exit()



                                        dic= red.Create_pd('reconcILS',replicate_,li,dic)

                                        df = pd.DataFrame(dic)
                                        df.to_csv(dupcoal_location+'_1_result.csv', index=False)
                                        oer= open(dupcoal_location+'_labeled_sp.csv','w+')
                                        oer.write(red.to_newick_sp(sp_large))
                                        oer.close()

                                        time_dic={'reconcILSTime_iterative':reconcILSTime_iterative,'ete_time':ete_time}
                                       

                                        df_time = pd.DataFrame(time_dic)




                                      
                                        df_time.to_csv(dupcoal_location+'_1_time_result.csv', index=False)

                                        mem_dic={'reconcILS_mem':reconcILS_mem,'ete_mem':ete_mem}
                                        
                                        dem_df  =pd.DataFrame(mem_dic)
                                        dem_df.to_csv(dupcoal_location+'_memory_result_with_dups_loss.csv', index=False)

                                except:
                                       continue
								

                            

fil.close()

            


   
