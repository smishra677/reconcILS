import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from scipy.stats import spearmanr
from sklearn.metrics import r2_score


'''
#ETE3 Vs GCf
x=[226,437,1952,1952,437,637,1358,554,554,1358,894,1527,625,1527,585,585,637,708,120,715,127]
y= [96.4,96.6,26.9,51.3,90.5,92.9,76.9,57.3,90.3,71.7,58.9,68.7,40.2,35.4,34.7,52,84.2,56.8,85.5,54.9,74.5]
'''
##
#y= [96.4,96.6,39.1,39.1,93.5,92.9,76.9,57.3,90.3,71.7,58.9,68.7,40.2,35.4,34.7,52,84.2,56.8,85.5,54.9,74.5]


'''
#reconcILS NNI all paralogy vs NNI SCO
x=[1604,2581,2600,5853,1817,6010,2112,1653,5631,8307,11766,4688,6813,5153,6662,3099,869,4437,581,5967,9677]
y=[150,342,370,851,267,846,290,271,885,1179,1727,660,939,711,859,504,114,636,65,855,1363]
'''

'''
# reconciLS NNI vs gcf smith et al .
x=[150,65,855,1363,342,370,851,267,846,290,271,504,114,636,885,1179,711,859,1727,660,939]
y= [96.4,96.6,51.3,26.9,90.5,84.2,56.8,85.5,54.9,74.5,92.9,76.9,90.3,57.3,71.7,58.9,68.7,40.2,35.4,52.1,34.7]
'''



print(len(x))
print(len(y))

for i in range(len(y)):
    print(i, y[i],x[i])

x =[abs(i) for i in x]
y =[abs(i) for i in y]

print(len(x)==len(y))
#x = [(1-(i / 1810))*100 for i in x]

df = pd.DataFrame({'X': x, 'Y': y})

sns.set(style="whitegrid")
plt.figure(figsize=(10, 6))
sns.regplot(x='X', y='Y', data=df, scatter_kws={'s': 50}, line_kws={'color': 'red'})
#plt.title('Correlation between X and Y')
#plt.xlabel('X')
#plt.ylabel('Y')

plt.title('Correlation between Duplication in ETE3 and gCF in IQ-Tree ')
plt.xlabel('Duplication in ETE3')
plt.ylabel('gCF in IQ-Tree')


spearman_correlation, _ = spearmanr(x, y)

r2 = r2_score(x, y)

print('spearman_correlation',spearman_correlation)
print('R2',r2)

correlation_coefficient = df.corr().iloc[0, 1]
print(correlation_coefficient)

plt.text(100, 100, f'Correlation: {correlation_coefficient:.2f} spearmanr: {spearman_correlation:.2f} r2_score: {r2:.2f}', fontsize=12, color='blue', bbox=dict(facecolor='white', alpha=0.5))

plt.show()



