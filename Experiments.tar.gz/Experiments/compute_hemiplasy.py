import os
from collections import Counter
import sys
sys.path.append("../../")
sys.path.append("../")
from reconcILS import *
from utils import *
import pandas as pd     
import sqlite3


conn = sqlite3.connect('./SimPhy_outfiles_40_0.003_0.0031/1/SimPhy_outfiles.db')
conn.row_factory = sqlite3.Row
cursor = conn.cursor()
query = "SELECT * FROM Locus_Trees"
cursor.execute(query)
rows = cursor.fetchall()
dic={'Hemiplasy':[]}
sum_d=0
sum_L=0
for i in rows:
    sum_d+=i['n_dup']
    sum_L+=i['n_loss']


print('average_duplication_Simphy_0.003_0.003========>',sum_d/1000)
print('average_Loss_Simphy_0.003_0.003========>',sum_L/1000)
print('Hemiplasy========>',0)
print('Rasmusen and Kellis -Hemiplasy========>',0)





def read_trees(i,folder):
        gene_tre= open(folder+'/rep_'+str(i)+'.tre')
        tr =gene_tre.read().strip().split('\n')
        gene_tre.close()
        return str(tr[0])




gene_folder='./dupcoal_40_0.03_0.03'

dic={'Process':[],'Replicate':[],'Gene_tree':[],'Species_Tree':[],'Duplication':[],'NNI':[],'DLCILS':[],'Loss':[],'Hemiplasy':[],'RHemiplasy':[]}

reco =reconcils()
red= readWrite.readWrite()

for replicate_ in range(1000):


    try:
        tree= str(read_trees(replicate_,os.path.join('./', gene_folder)))
        tree  = tree.replace('e-', '0')
        tr=red.parse(tree)
        dic= red.read_log('True Process',replicate_,dic,gene_folder)
    except:
        continue


print('#######################################################################################')

print('average_duplication_Dupcoal_0.03_0.03========>',sum(dic['Duplication'])/len(dic['Duplication']))
print('average_loss_Dupcoal_0.03_0.03========>',sum(dic['Loss'])/len(dic['Duplication']))
print('Hemiplasy',sum(dic['Hemiplasy']))
print('Rasmusen and Kellis - Hemiplasy',sum(dic['RHemiplasy']))
print('###########################################################################################')
