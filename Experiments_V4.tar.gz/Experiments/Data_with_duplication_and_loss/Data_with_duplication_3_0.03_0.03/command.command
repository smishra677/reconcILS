python3 dupcoal_v3.0.0.py --stree sp_tree.tre --mu_par 0.03 --lambda_par 0.03  --reps 1000 --output Data_with_duplication_3_0.03_0.03
