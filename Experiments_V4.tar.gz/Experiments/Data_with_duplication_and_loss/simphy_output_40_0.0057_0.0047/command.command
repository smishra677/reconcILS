python3 dupcoal_v3.0.0.py --stree species_40_with_branch_lengths.tre --mu_par 0.03 --lambda_par 0.03  --reps 1000 --output Data_with_duplication_40_0.03_0.03
