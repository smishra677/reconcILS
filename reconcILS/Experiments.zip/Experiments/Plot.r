library(ape)
library(ggtree)
library(ggplot2)
library(tidyr)
library(ggstar)
library(stringr)


Normalizing_factor=1820
newick_str <- "(0-0-209   0-0-226   A,(((0-0-169   0-0-1751   W,0-0-154   0-0-1736   V)0-1148-10   0-0-908   ,(0-0-142   0-0-1320   B,0-0-156   0-0-1334   U)0-735-11   0-0-1313   )110-62-120   1429-0-467   ,((((0-0-143   0-0-2134   K,0-0-129   0-0-2120   L)0-593-102   0-0-1110   ,(0-0-75   0-0-1802   M,0-0-56   0-0-1783   N)0-101-169   0-0-1441   )8-433-289   519-0-1733   ,(0-0-569   0-0-2033   J,((0-0-299   0-0-2649   E,(0-0-177   0-0-3570   D,0-0-164   0-0-3557   H)0-785-132   0-0-2163   )0-503-539   625-0-3074   ,((0-0-342   0-0-3546   C,0-0-355   0-0-3559   I)0-689-332   0-0-2145   ,(0-0-286   0-0-3494   G,0-0-270   0-0-3478   F)0-465-385   0-0-2194   )44-1314-216   462-0-3346   )334-977-67   815-0-1980   )183-796-125   464-0-1536   )309-314-114   596-0-887   ,(0-0-222   0-0-1230   T,(0-0-160   0-0-1399   S,(0-0-138   0-0-1447   O,((0-0-63   0-0-1066   Q,0-0-51   0-0-1054   R)0-273-42   0-0-1935   ,0-0-123   0-0-1982   P)0-815-35   127-0-1037   )0-215-40   601-0-1425   )17-788-32   83-0-740   )32-338-167   587-0-836   )176-383-22   242-0-403   )87-168-0   150-0-199   )58-0-0   226-0-0   ;"
annotations <- stringr::str_extract_all(newick_str, "(\\d+-\\d+-\\d+\\s+\\d+-\\d+-\\d+)")[[1]]
clean_newick_str <- str_replace_all(newick_str, "\\d+-\\d+-\\d+", "")
print(clean_newick_str)


tr <- read.tree(text = clean_newick_str)

p <- ggtree(tr) + 
  geom_tiplab(angle=90, hjust=1, fontface="bold") +
  geom_nodelab(aes(label=node),angle = 100)

# Print the modified plot
print(p)
tip_labels <- tr$tip.label
print(tip_labels)

p <- ggtree(tr)




p <- p + geom_nodelab(aes(label=node),angle = 100)

print(p)
print(p)

split_annotations <- lapply(annotations, function(x) as.numeric(unlist(strsplit(x, "-"))))
print(annotations)

a1 <- list()
b1 <- list()
c1 <- list()

a2 <- list()
b2 <- list()
c2 <- list()


for (i in 1:length(annotations)) {
  parts <- unlist(strsplit(annotations[i], "\\s+"))
  
  nums1 <- unlist(strsplit(parts[1], "-"))
  a1[[i]] <- as.numeric(nums1[1])
  b1[[i]] <- as.numeric(nums1[2])
  c1[[i]] <- as.numeric(nums1[3])
  
  nums2 <- unlist(strsplit(parts[2], "-"))
  a2[[i]] <- as.numeric(nums2[1])
  b2[[i]] <- as.numeric(nums2[2])
  c2[[i]] <- as.numeric(nums2[3])
}


a1 <- unlist(a1)
b1 <- unlist(b1)
c1 <- unlist(c1)

a2 <- unlist(a2)
b2 <- unlist(b2)
c2 <- unlist(c2)


dat <- data.frame(a =a1, b = b1, c = c1, e=a2,f=b2,g=c2)
rowSumsWithoutD <- rowSums(dat[, !names(dat) %in% c('d')])
total_sum= sum(dat)

normalizedDat <- as.data.frame(lapply(dat[, !names(dat) %in% c('d')], function(x) x / (Normalizing_factor*3.6)))


dat<-normalizedDat
print(normalizedDat)
#dat<-normalizedDat
#dat$node <-c(1, 2, 3, 4, 5, 6, 35, 34, 7, 8, 9, 39, 10, 11, 40, 38, 18, 19, 44, 20, 21, 45, 43, 22, 23, 24, 25, 49, 48, 26, 27, 51, 28, 29, 52, 50, 47, 46, 42, 12, 13, 14, 16, 17, 57, 15, 56, 55, 54, 53, 41, 37, 36, 33, 32, 31, 30)

print(dat)

print(dat$a)


print(dat$e)



dat1 <- data.frame(a=dat$a, b=dat$b, c=dat$c, e=dat$e, f=dat$f,g=dat$g)
#dat1$node <-c(9,10,11,31,30,8,29,7,28,6,27,20,21,36,22,23,37,35,18,19,39,17,38,34,16,33,12,13,41,14,15,42,40,32,26,2,3,44,4,5,45,43,25,1,24)
dat1$node <- c(1,2,3,27,4,5,28,26,12,13,32,14,15,33,31,16,17,18,19,37,36,20,21,39,22,23,40,38,35,34,30,6,7,8,10,11,45,9,44,43,42,41,29,25,24)

dat2 <- data.frame(a =dat$e, b =dat$f, c = dat$g, e=-dat$a, f=-dat$b,g=-dat$c)
#dat2$node <-c(9,10,11,31,30,8,29,7,28,6,27,20,21,36,22,23,37,35,18,19,39,17,38,34,16,33,12,13,41,14,15,42,40,32,26,2,3,44,4,5,45,43,25,1,24)
dat2$node <- c(1,2,3,27,4,5,28,26,12,13,32,14,15,33,31,16,17,18,19,37,36,20,21,39,22,23,40,38,35,34,30,6,7,8,10,11,45,9,44,43,42,41,29,25,24)

print(dat1)

dat1 <- dat1[match(1:max(dat1$node), dat1$node), ]
dat2 <- dat2[match(1:max(dat1$node), dat2$node), ]



print(dat1)
print(dat2)
library(ggtree)
library(ggplot2)


scaleA <- 1
scaleB <- 1
scaleC <- 1

baseWidth <- 0.1
gap<-0.1
p <- ggtree(tr) +
  geom_rect(aes(ymin = y, ymax = y + dat1$a/scaleA, xmin = x - baseWidth * 3, xmax = x - baseWidth * 2),
            fill = 'green', color = 'black') +
  geom_rect(aes(ymin = y, ymax = y + dat1$b/scaleB, xmin = x - baseWidth * 2, xmax = x - baseWidth),
            fill = 'red', color = 'black') +
  geom_rect(aes(ymin = y, ymax = y + dat1$c/scaleC, xmin = x - baseWidth, xmax = x),
            fill = 'blue', color = 'black') +
  geom_rect(aes(ymin = y - dat2$a/scaleA - gap, ymax = y - gap, xmin = x - baseWidth * 3, xmax = x - baseWidth * 2),
            fill = 'green', color = 'black') +
  geom_rect(aes(ymin = y - dat2$b/scaleB - gap, ymax = y - gap, xmin = x - baseWidth * 2, xmax = x - baseWidth),
            fill = 'red', color = 'black') +
  geom_rect(aes(ymin = y - dat2$c/scaleC - gap, ymax = y - gap, xmin = x - baseWidth, xmax = x),
            fill = 'blue', color = 'black')

print(p+  geom_tiplab(angle=90, hjust=1, fontface="bold") +
        geom_nodelab(aes(label=node),angle = 100))



