import os
import tracemalloc

import sys
sys.path.append("../../")
sys.path.append("../")

from reconcILS import *
from utils_reconcILS import *
import pandas as pd     

from ete3 import TreeNode
from  ete3 import phylo
from ete3 import PhyloTree

from ete3 import NCBITaxa




#dupcoal_location='./Data_with_duplication_40_species_0.03_0.03/'
dupcoal_location='./Data_with_duplication_and_loss/Dupcoal_output_40_0.03_0.03/'

dic={'Process':[],'Replicate':[],'Gene_tree':[],'Species_Tree':[],'Duplication':[],'NNI':[],'DLCILS':[],'Loss':[],'Hemiplasy':[],'RHemiplasy':[]}
dic_simphy={'Process':[],'Replicate':[],'Gene_tree':[],'Species_Tree':[],'Duplication':[],'NNI':[],'Loss':[]}


    
from collections import Counter

def convert_1(df,df1):
    df['Loss'].append(sum(list(df1['loss'])))
    df['NNI'].append(sum(list(df1['coal'])))
    df['Duplication'].append(sum(list(df1['dup'])))

    
    return df

def convert(df,df1):
    df['Loss'].append(sum(list(df1['loss'])))
    df['DLCILS'].append(sum(list(df1['coal'])))
    df['Duplication'].append(sum(list(df1['dup'])))
    df['Hemiplasy'].append(0)
    df['NNI'].append(0)
    df['RHemiplasy'].append(0)
    
    return df

def put_it_in_sp(df,node_to_leaves,species_edge_list):

    events={idx:{'D':0,'I':0,'L':0} for idx in species_edge_list}
    for idx, row in df.iterrows():

        if int(row['parentid'])==-1:
            if row['nodeid'].isnumeric():
                start= repr(list(sorted(node_to_leaves[str(row['nodeid'])])))
                #events[(start,' to ',start)]= {'D':row['dup'],'I':row['coal'],'L':row['loss']}
            else:
                start =repr(list({row['nodeid']}))
        
        else:
            start=repr(list(sorted(node_to_leaves[str(row['parentid'])])))
        end=''


        if row['nodeid'].isnumeric():
            end= repr(list(sorted(node_to_leaves[str(row['nodeid'])])))
        else:
            end =repr(list({row['nodeid']}))
        

        if (start,' to ',end) in events:
               events[(start,' to ',end)]= {'D':row['dup'],'I':row['coal'],'L':row['loss']}


    return events

def label_reconcILS(li):
        li.reverse()
        dic_reconcILS={}
        for i in li:
                if type(i)==list:
                        if (repr(list(sorted(i[0]))),' to ',repr(list(sorted(i[1]))))  in dic_reconcILS.keys():
                                if i[3]==True:
                                        dic_reconcILS[(repr(list(sorted(i[0]))),' to ',repr(list(sorted({i[1]}))))]+=[i[2]]
                                else:
                                        dic_reconcILS[(repr(list(sorted(i[0]))),' to ',repr(list(sorted(i[1]))))]+=[i[2]]
                        else:   
                                if i[3]==True:
                                        dic_reconcILS[(repr(list(sorted(i[0]))),' to ',repr(list(sorted({i[1]}))))]=[i[2]]
                                else:
                                        dic_reconcILS[(repr(list(sorted(i[0]))),' to ',repr(list(sorted(i[1]))))]=[i[2]]
        
        return dic_reconcILS

def label_ete3(recon_tree, fr):
    coun = 0
    coun1 = 0

    for node in recon_tree.traverse(strategy="preorder"):
        if len(node.children) >= 0:
            if hasattr(node, 'evoltype'):
                if node.evoltype in ['D', 'L']:
                    if node.evoltype == 'D':
                        coun += 1

                    node_ = sorted(node.get_species())

                    if node.evoltype == 'L' and len(node.children) > 1:
                        if not hasattr(node.children[1], 'evoltype') or not hasattr(node.children[0], 'evoltype'):
                            continue
                        else:
                            if node.up:
                                node_up = sorted(node.up.get_species())
                                if node.evoltype == 'L' and node_up == node_:
                                    continue
                                elif (repr(node_up), ' to ', repr(node_)) in fr.keys():
                                    fr[(repr(node_up), ' to ', repr(node_))] += [node.evoltype]
                                else:
                                    fr[(repr(node_up), ' to ', repr(node_))] = [node.evoltype]
                            else:
                                if (repr(node_), ' to ', repr(node_)) in fr.keys():
                                    fr[(repr(node_), ' to ', repr(node_))] += [node.evoltype]
                                else:
                                    fr[(repr(node_), ' to ', repr(node_))] = [node.evoltype]

                            if hasattr(node.children[1], 'evoltype'):
                                node.children[1].evoltype = 'S'
                            if hasattr(node.children[0], 'evoltype'):
                                node.children[0].evoltype = 'S'

                    else:
                        if node.up:
                            node_up = sorted(node.up.get_species())
                            tem_node = node.up

                            while node_ == node_up:
                                if tem_node.up:
                                    node_up = sorted(tem_node.up.get_species())
                                    tem_node = tem_node.up
                                else:
                                    break

                            if node.evoltype == 'D':
                                coun1 += 1

                            if (repr(node_up), ' to ', repr(node_)) in fr.keys():
                                fr[(repr(node_up), ' to ', repr(node_))] += [node.evoltype]
                            else:
                                fr[(repr(node_up), ' to ', repr(node_))] = [node.evoltype]
                        else:
                            if (repr(node_), ' to ', repr(node_)) in fr.keys():
                                fr[(repr(node_), ' to ', repr(node_))] += [node.evoltype]
                            else:
                                fr[(repr(node_), ' to ', repr(node_))] = [node.evoltype]
    return fr






def read_trees(i,folder):
        gene_tre= open(folder+'/rep_'+str(i)+'.tre')
        tr =gene_tre.read().strip().split('\n')
        gene_tre.close()
        return str(tr[0])

def write_trees(i,folder,tree):
        with open(folder+'/rep_1_'+str(i)+'.tre', 'w') as f:
            f.write(tree)
        

import timeit

def dlcpar(gene_folder,i):
    command1= 'python2 ./dlcpar dp -D 1.1 -L 1.0 -C 1.0 -K 1.0 -s ./sp_tree.tre -S ./001/001.mapsl  ./'+gene_folder+'/rep_1_'+str(i)+'.tre'
    command2= 'python2 ./dlcpar events --lct -s ./sp_tree.tre -S ./001/001.mapsl ./'+gene_folder+'/rep_1_'+str(i)+'.tre.dlcdp.lct.tree > result_data'
    os.system(command1)
    os.system(command2)


sp_string='((((M,(AF,B)),(P,(AJ,(AE,(O,D))))),((W,AH),((AN,N),((X,AG),(R,E))))),((H,(Y,AB)),((((L,V),(AC,A)),((C,Z),(F,K))),(((AM,AA),(AL,(T,(U,AI)))),((S,(G,AD)),((Q,J),(I,AK)))))));'
#sp_string='(A,(B,C));'




def find_leaves(node, df):
    if not node.isnumeric():
        return node


    children = df[df['parentid'] == int(node)]['nodeid'].tolist()

    if not children:
        return {node}
    else:
        result = set()
        for child in children:
            result.update(find_leaves(child, df))
        return result


def Create_pd_ete3_1(flag,i,o,dic):
        dic['Process']+=[flag]
        dic['Replicate']+=[i]
        dic['Duplication'].append(0)
        dic['Loss'].append(0)
        dic['NNI'].append(0)

        

        for i in o:
            print(i)
            if i in ['D','L']:
                    if i =='D':
                        dic['Duplication'][-1]=o[i]
                    elif i=='L':
                        dic['Loss'][-1]=o[i]
                    else:
                        continue
        print(o)
        return dic

def find_replacement_for_edge(species_edge_list,fr):
        list_to_replace ={}
        for edge in fr:
                if edge not in species_edge_list:
                        for edge_sp in species_edge_list:
                                if edge[2] in edge_sp[2]:
                                        list_to_replace[edge]=edge_sp


        for edge in list_to_replace:
                fr[list_to_replace[edge]]= fr[edge]
        
        return fr

def put_it_in_sp_tree(species_edge_list,dic_reconcILS,fr):
        for i in species_edge_list:
                rec_in_dic= {'D':0,'I':0,'L':0}
                if i in dic_reconcILS:
                        dic_in= dict(Counter(dic_reconcILS[i]))
                        for j in rec_in_dic:
                                if j in dic_in:
                                        rec_in_dic[j]=dic_in[j]
                                        eve_rec[j]+=dic_in[j]
                        dic_reconcILS[i]=rec_in_dic
                else:
                        dic_reconcILS[i]={'D':0,'I':0,'L':0}
                                                        
                                                
                ete_in_dic= {'D':0,'I':0,'L':0}

                if i in fr:
                        dic_in= dict(Counter(fr[i]))
                        for j in ete_in_dic:
                                if j in dic_in:
                                        ete_in_dic[j]=dic_in[j]
                                        eve_ete[j]+=dic_in[j]
                        fr[i]=ete_in_dic
                else:
                        fr[i]={'D':0,'I':0,'L':0}
        return dic_reconcILS,fr
                








#gene_tre= open('./output_gene/gene_tree.txt')
#trees =gene_tre.read().strip().split('\n')
#gene_tre.close()


value=0
previous_dict={}
erro=0
fil= open(dupcoal_location+'run_1_1_5_error.txt','w+')
#sp ='(((A,B),C),D);'
dlcparTime=[]
reconcILSTime_iterative=[]
reconcILSTime_iterative_simphy=[]

reconcILSTime_recurssive=[]
ete_time=[]
ete_time_simphy=[]

ete_mem=[]
reconcILS_mem=[]


li_gt=[]
lis_rep=[]
red= readWrite.readWrite()
sp_large=red.parse_bio(sp_string)
sp_large_simphy=red.parse_bio(sp_string)

sp_str_ref=sp_large.to_newick()



reco =reconcils()

sp_large=sp_large.parse(sp_str_ref)
sp_large.label_internal()
species_edge_list=reco.get_edges(sp_large)

sp_large_simphy=sp_large_simphy.parse(sp_str_ref)
sp_large_simphy.label_internal()

sp_large_simphy=sp_large_simphy.parse(sp_str_ref)
sp_large_simphy.label_internal()

op_tree = open(dupcoal_location+'trees.tre').read().split('\n')
op_event = pd.read_csv(dupcoal_location+'summary.csv')
#for replicate,duplications,observed_duplications,losses,CNH,RKH,ILS,ILS_DLCPAR in zip(op_event['replicate'],op_event['duplications'],op_event['observed_duplications'],op_event['losses'],op_event['CNH'],op_event['RKH'],op_event['ILS'],op_event['ILS_DLCPAR']):
#print(i)
for replicate_ in range(1000):
                                print(replicate_)

                                sp=red.parse(sp_string)
                                if erro==1:
                                    dic=previous_dict

                                previous_dict=dic

                                DATA_PATH = "./"
                                file_path = os.path.join(DATA_PATH)


                                try:

                                    li_gt=[]
                                    lis_rep=[]
                                    sp=red.parse(sp_string)
                                    tree= str(op_tree[replicate_])
                                    tree  = tree.replace('e-', '0')
                                    #tree='(AA,((T,U),((AM,(AI,(AL,AL))),((AA,AM),(T,(U,AI))))))'
                                    tr=red.parse(tree)
                                    dic['Process'] +=['True Process']
                                    dic['Replicate'] +=[op_event['replicate'][replicate_]]
                                    dic['Gene_tree'] +=[op_tree[replicate_]]
                                    dic['Species_Tree']+=[sp_string]
                                    dic['Duplication'] +=[op_event['observed_duplications'][replicate_]]
                                    dic['NNI'] +=[op_event['ILS'][replicate_]]
                                    dic['DLCILS'] +=[op_event['ILS_DLCPAR'][replicate_]]
                                    dic['Loss'] +=[op_event['losses'][replicate_]]
                                    dic['Hemiplasy'] +=[op_event['CNH'][replicate_]]
                                    dic['RHemiplasy'] +=[op_event['RKH'][replicate_]]


                                    lis_rep.append(replicate_)
                                    li_gt.append(tr.to_newick())

                                    print(tr.to_newick())
                                    print(replicate_)
                                    write_trees(replicate_,os.path.join(file_path, dupcoal_location),tr.to_newick())
                                    sp_large_small=sp_large.parse(sp_str_ref)
                                    sp_large_small.label_internal()

                                    starttime = timeit.default_timer()

                                    tracemalloc.start()
                                
                                    genetree = PhyloTree(tr.to_newick())
                                    
                                    sptree = PhyloTree(sp_string)
                        
                                    
                                    
                                    recon_tree, events = genetree.reconcile(sptree)
                                    current, peak = tracemalloc.get_traced_memory()
                                    ete_mem.append(peak / 10**6)
                                    tracemalloc.stop()
                                    ete_time.append(timeit.default_timer()-starttime)
                                    dic['Gene_tree']+=[tr.to_newick()]
                                    dic['Species_Tree']+=[sp_string]

                                
                                    dic= red.Create_pd_ete3('ETE3',replicate_,dict(Counter(red.sp_event_ete3(recon_tree,events))),dic)

                                    fr={}
                                    fr = red.label_ete3(recon_tree,fr)


                    

                                    #try:
                                    tracemalloc.start()
                                    sp_copy= copy.deepcopy(sp)
                                    sp_copy.reset()
                                    reco.gene_tree=copy.deepcopy(tr)

                                    tr.order_gene(sp)

                                    tr.label_internal()
                                    sp.label_internal()



                                    tr.map_gene(sp)
                                    reco.setCost(sp)

                                    sp.isRoot=True
                                    tr.isRoot=True
                                    sp_copy.isRoot=True

                                    
                                    
                                    starttime1 = timeit.default_timer()
                                    reco.L_cost=  1
                                    reco.D_cost=  1
                                    reco.I_cost=  5
                                    #reco.V=1
                                    if tree=='None':
                                        li=[[sp.taxa,sp.taxa,'L',None]]
                                    else:
                                        li=reco.iterative_reconcILS(tr,sp,sp_copy,sp,[])
                                    current, peak = tracemalloc.get_traced_memory()
                                    reconcILS_mem.append(peak / 10**6)
                                    tracemalloc.stop()
                                    reconcILSTime_iterative.append(timeit.default_timer()-starttime1)
                                    print(111111111111111111111111111111111111111111)
                                    #pprint.pprint(li)
                                    dic['Gene_tree']+=[red.to_newick(reco.gene_tree)]
                                    
                                    dic['DLCILS']+=[0]
                                    dic['Hemiplasy']+=[0]
                                    dic['RHemiplasy']+=[0]
                                    #li =red.sp_event(sp,[])
                                    if len(li)==0:

                                        continue
                                    else:   
                                        print('##############################################################################################')
                                        dic_reconcILS=red.label_reconcILS(li)
                                        #pprint.pprint(dic_reconcILS)
                                        print('##############################################################################################')


                                        fr = red.find_replacement_for_edge(species_edge_list,fr)
                                        dic_reconcILS,fr,eve_rec,eve_ete=red.put_it_in_sp_tree(species_edge_list,dic_reconcILS,fr)

                                        #sp=sp.parse(sp_str_ref)
                                        #sp.label_internal()

                                        reco.edge_to_event(sp_large,dic_reconcILS,0) 
                                        reco.edge_to_event(sp_large,fr,1)
                                                                                
                                                                                
                                        reco.edge_to_event(sp_large_small,dic_reconcILS,0) 
                                        reco.edge_to_event(sp_large_small,fr,1)
                                        
                                        dic['Species_Tree']+=[red.to_newick_sp(sp_large_small)]



                                        if eve_ete['L']!= dic['Loss'][-1]:
                                                print('Loss Not matching dupcoal',replicate_,eve_ete['L'], dic['Loss'][-1])
                                                exit()
                                        if eve_ete['D']!= dic['Duplication'][-1]:
                                                print('Duplication Not matching dupcoal',replicate_,eve_ete['D'], dic['Duplication'][-1])
                                                exit()



                                        dic= red.Create_pd('reconcILS',replicate_,li,dic)

                                        df = pd.DataFrame(dic)
                                        df.to_csv(dupcoal_location+'reconcILS_1_1_5_result.csv', index=False)
                                        oer= open(dupcoal_location+'reconcILS_1_1_5_labeled_sp.csv','w+')
                                        oer.write(red.to_newick_sp(sp_large))
                                        oer.close()

                                        time_dic={'reconcILSTime_iterative':reconcILSTime_iterative,'ete_time':ete_time}
                                       

                                        df_time = pd.DataFrame(time_dic)




                                      
                                        df_time.to_csv(dupcoal_location+'reconcILS_1_1_5_time_result.csv', index=False)

                                        mem_dic={'reconcILS_mem':reconcILS_mem,'ete_mem':ete_mem}
                                        
                                        dem_df  =pd.DataFrame(mem_dic)
                                        dem_df.to_csv(dupcoal_location+'reconcILS_1_1_5_memory_result_with_dups_loss.csv', index=False)

                                except:
                                       fil.write('error',replicate_)
                                       continue
								

                                


            
        



fil.close()

            


   
