from collections import Counter
import pandas as pd     
import sqlite3

#simphy_location='./Data_with_duplication_and_loss/SimPhy_outfiles_40_0.003_0.003/'
simphy_location='/N/u/samishr/Quartz/Desktop/reconcILS_03_18/reconcILS-main/reconcILS/example/Data_with_duplication_and_loss/simphy_output_40_0.0057_0.0047'

dupcoal_location='./example_40_only_ILS/'


conn = sqlite3.connect(simphy_location+'/simphy_output_40_0.0057_0.0047.db')
conn.row_factory = sqlite3.Row
cursor = conn.cursor()
query = "SELECT * FROM Locus_Trees"
cursor.execute(query)
rows = cursor.fetchall()
dic={'Hemiplasy':[]}
sum_d=0
sum_L=0
for i in rows:
    sum_d+=i['n_dup']
    sum_L+=i['n_loss']


print('average_duplication_Simphy_0.003_0.003========>',sum_d/1000)
print('average_Loss_Simphy_0.0025_0.003========>',sum_L/1000)
print('Hemiplasy========>',0)
print('Rasmusen and Kellis -Hemiplasy========>',0)





gene_folder='./Data_with_duplication_and_loss/Dupcoal_output_40_0.03_0.03/summary.csv'

op_event = pd.read_csv(gene_folder)


print('#######################################################################################')

print('average_duplication_Dupcoal_0.03_0.03========>',sum(op_event['duplications'])/len(op_event['duplications']))
print('average_loss_Dupcoal_0.03_0.03========>',sum(op_event['losses'])/len(op_event['losses']))
print('Hemiplasy',sum(op_event['CNH']))
print('Rasmusen and Kellis - Hemiplasy',sum(op_event['RKH']))
print('###########################################################################################')
