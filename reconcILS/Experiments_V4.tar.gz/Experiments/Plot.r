library(ape)
library(ggtree)
library(ggplot2)
library(tidyr)
library(ggstar)
library(stringr)


#Uncomment normalizing factor to match the dataset
sco=1820
#all_paralogs=11555

Normalizing_factor=sco


#Replace the Newick String
newick_str <- "(0-0-227   0-0-226   A,(((0-0-57   0-0-1319   W,0-0-42   0-0-1304   V)0-1363-9   0-0-768   ,(0-0-30   0-0-879   B,0-0-44   0-0-893   U)0-855-10   0-0-1182   )0-65-162   1952-0-572   ,((((0-0-103   0-0-780   K,0-0-89   0-0-766   L)0-636-81   0-0-461   ,(0-0-66   0-0-191   M,0-0-47   0-0-172   N)0-114-117   0-0-1049   )0-504-271   554-0-1244   ,(0-0-368   0-0-2153   J,((0-0-145   0-0-1496   E,(0-0-97   0-0-1049   D,0-0-84   0-0-1036   H)0-859-58   0-0-457   )0-711-209   625-0-2451   ,((0-0-125   0-0-1167   C,0-0-138   0-0-1180   I)0-939-118   0-0-1568   ,(0-0-111   0-0-841   G,0-0-95   0-0-825   F)0-660-129   0-0-1891   )0-1727-119   585-0-1180   )28-1179-44   1527-0-360   )44-885-116   894-0-657   )189-271-92   1358-0-631   ,(0-0-163   0-0-1279   T,(0-0-90   0-0-1149   S,(0-0-86   0-0-1187   O,((0-0-47   0-0-416   Q,0-0-35   0-0-404   R)0-290-24   0-0-712   ,0-0-89   0-0-1146   P)0-846-17   127-0-188   )0-267-22   715-0-695   )0-851-26   120-0-203   )0-370-221   708-0-659   )158-342-16   637-0-128   )108-150-0   437-0-0   )76-0-0   226-0-0   ;"

annotations <- stringr::str_extract_all(newick_str, "(\\d+-\\d+-\\d+\\s+\\d+-\\d+-\\d+)")[[1]]
clean_newick_str <- str_replace_all(newick_str, "\\d+-\\d+-\\d+", "")
print(clean_newick_str)


tr <- read.tree(text = clean_newick_str)

p <- ggtree(tr) + 
  geom_tiplab(angle=90, hjust=1, fontface="bold") +
  geom_nodelab(aes(label=node),angle = 100)

# Print the modified plot
print(p)
tip_labels <- tr$tip.label
print(tip_labels)

p <- ggtree(tr)




p <- p + geom_nodelab(aes(label=node),angle = 100)

print(p)
print(p)

split_annotations <- lapply(annotations, function(x) as.numeric(unlist(strsplit(x, "-"))))
print(annotations)

a1 <- list()
b1 <- list()
c1 <- list()

a2 <- list()
b2 <- list()
c2 <- list()


for (i in 1:length(annotations)) {
  parts <- unlist(strsplit(annotations[i], "\\s+"))
  
  nums1 <- unlist(strsplit(parts[1], "-"))
  a1[[i]] <- as.numeric(nums1[1])
  b1[[i]] <- as.numeric(nums1[2])
  c1[[i]] <- as.numeric(nums1[3])
  
  nums2 <- unlist(strsplit(parts[2], "-"))
  a2[[i]] <- as.numeric(nums2[1])
  b2[[i]] <- as.numeric(nums2[2])
  c2[[i]] <- as.numeric(nums2[3])
}


a1 <- unlist(a1)
b1 <- unlist(b1)
c1 <- unlist(c1)

a2 <- unlist(a2)
b2 <- unlist(b2)
c2 <- unlist(c2)


dat <- data.frame(a =a1, b = b1, c = c1, e=a2,f=b2,g=c2)
rowSumsWithoutD <- rowSums(dat[, !names(dat) %in% c('d')])
total_sum= sum(dat)

normalizedDat <- as.data.frame(lapply(dat[, !names(dat) %in% c('d')], function(x) x / (Normalizing_factor*1.8)))


dat<-normalizedDat
print(normalizedDat)
#dat<-normalizedDat
#dat$node <-c(1, 2, 3, 4, 5, 6, 35, 34, 7, 8, 9, 39, 10, 11, 40, 38, 18, 19, 44, 20, 21, 45, 43, 22, 23, 24, 25, 49, 48, 26, 27, 51, 28, 29, 52, 50, 47, 46, 42, 12, 13, 14, 16, 17, 57, 15, 56, 55, 54, 53, 41, 37, 36, 33, 32, 31, 30)

print(dat)

print(dat$a)


print(dat$e)



dat1 <- data.frame(a=dat$a, b=dat$b, c=dat$c, e=dat$e, f=dat$f,g=dat$g)
#dat1$node <-c(9,10,11,31,30,8,29,7,28,6,27,20,21,36,22,23,37,35,18,19,39,17,38,34,16,33,12,13,41,14,15,42,40,32,26,2,3,44,4,5,45,43,25,1,24)
#dat1$node <- c(1,2,3,27,4,5,28,26,12,13,32,14,15,33,31,16,17,18,19,37,36,20,21,39,22,23,40,38,35,34,30,6,7,8,10,11,45,9,44,43,42,41,29,25,24)
dat1$node <- c(1,2,3,27,4,5,28,26,6,7,32,8,9,33,31,10,11,12,13,37,36,14,15,39,16,17,40,38,35,34,30,18,19,20,21,22,23,45,44,43,42,41,29,25,24)
dat2 <- data.frame(a =dat$e, b =dat$f, c = dat$g, e=-dat$a, f=-dat$b,g=-dat$c)
#dat2$node <-c(9,10,11,31,30,8,29,7,28,6,27,20,21,36,22,23,37,35,18,19,39,17,38,34,16,33,12,13,41,14,15,42,40,32,26,2,3,44,4,5,45,43,25,1,24)
#dat2$node <- c(1,2,3,27,4,5,28,26,12,13,32,14,15,33,31,16,17,18,19,37,36,20,21,39,22,23,40,38,35,34,30,6,7,8,10,11,45,9,44,43,42,41,29,25,24)
dat2$node <-c(1,2,3,27,4,5,28,26,6,7,32,8,9,33,31,10,11,12,13,37,36,14,15,39,16,17,40,38,35,34,30,18,19,20,21,22,23,45,44,43,42,41,29,25,24)
print(dat1)

dat1 <- dat1[match(1:max(dat1$node), dat1$node), ]
dat2 <- dat2[match(1:max(dat1$node), dat2$node), ]



print(dat1)
print(dat2)


scaleA <- 1
scaleB <- 1
scaleC <- 1

baseWidth <- 0.1
gap<-0.1
p <- ggtree(tr) +
  geom_rect(aes(ymin = y, ymax = y + dat1$a/scaleA, xmin = x - baseWidth * 3, xmax = x - baseWidth * 2),
            fill = '#4C9F8A', color = 'black') +
  geom_rect(aes(ymin = y, ymax = y + dat1$b/scaleB, xmin = x - baseWidth * 2, xmax = x - baseWidth),
            fill = '#F29F00', color = 'black') +
  geom_rect(aes(ymin = y, ymax = y + dat1$c/scaleC, xmin = x - baseWidth, xmax = x),
            fill = '#A62C2E', color = 'black') +
  geom_rect(aes(ymin = y - dat2$a/scaleA - gap, ymax = y - gap, xmin = x - baseWidth * 3, xmax = x - baseWidth * 2),
            fill = '#4C9F8A', color = 'black') +
  geom_rect(aes(ymin = y - dat2$b/scaleB - gap, ymax = y - gap, xmin = x - baseWidth * 2, xmax = x - baseWidth),
            fill = '#F29F00', color = 'black') +
  geom_rect(aes(ymin = y - dat2$c/scaleC - gap, ymax = y - gap, xmin = x - baseWidth, xmax = x),
            fill = '#A62C2E', color = 'black')

print(p +geom_tiplab(angle=90, hjust=1, fontface="bold") 
)


ggsave("/home/gbob/Downloads/ReconcILS_5_6/reconcILS-Test/reconcILS_clone_6_12/reconcILS/reconcILS/example/all_paralogy.jpg", plot = p,  dpi = 500)

