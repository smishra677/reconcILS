import os

import sys
sys.path.append("../../")
sys.path.append("../")

from reconcILS import *
from utils import *
import pandas as pd     

from ete3 import TreeNode
from  ete3 import phylo
from ete3 import PhyloTree

from ete3 import NCBITaxa
import os







def read_trees(i,folder):
        gene_tre= open(folder+'/rep_'+str(i)+'.tre')
        tr =gene_tre.read().strip().split('\n')
        gene_tre.close()
        return str(tr[0])






gene_folder='./1'


simphy_2N=[]
simphy_N=[]
dupcoal=[]
dic_2N ={'(C,(A,B));':0,'(B,(A,C));':0,'(A,(B,C));':0}
dic_N ={'(C,(A,B));':0,'(B,(A,C));':0,'(A,(B,C));':0}
dic_dupcoal ={'(C,(A,B));':0,'(B,(A,C));':0,'(A,(B,C));':0}

for i in range(1000):
        red= readWrite.readWrite()
        tree= str(open('./SimPhy_outfiles_2N/'+gene_folder+'/g_trees'+str(i+1).zfill(4)+'.trees').read())
        tree= tree.replace('e-', '0')
        tr=red.parse(tree)
        simphy_2N.append(tr.to_newick())

        tree= str(open('./SimPhy_outfiles/'+gene_folder+'/g_trees'+str(i+1).zfill(4)+'.trees').read())
        tree= tree.replace('e-', '0')
        tr=red.parse(tree)
        simphy_N.append(tr.to_newick())

        tree= str(read_trees(i,os.path.join('./', 'example_just_ILS')))
        tree= tree.replace('e-', '0')
        tr=red.parse(tree)
        dupcoal.append(tr.to_newick())
        
for i in dupcoal:
    if i in ['(C,(A,B));','((A,B),C);','(C,(B,A));','((B,A),C);']:
        dic_dupcoal['(C,(A,B));']+=1

    if i in ['(B,(A,C));','((A,C),B);','(B,(C,A));','((C,A),B);']:
        dic_dupcoal['(B,(A,C));']+=1

    if i in ['(A,(B,C));','((B,C),A);','(A,(C,B));','((C,B),A);']:
        dic_dupcoal['(A,(B,C));']+=1


for i in simphy_2N:
    if i in ['(C,(A,B));','((A,B),C);','(C,(B,A));','((B,A),C);']:
        dic_2N['(C,(A,B));']+=1

    if i in ['(B,(A,C));','((A,C),B);','(B,(C,A));','((C,A),B);']:
        dic_2N['(B,(A,C));']+=1

    if i in ['(A,(B,C));','((B,C),A);','(A,(C,B));','((C,B),A);']:
        dic_2N['(A,(B,C));']+=1


for i in simphy_N:
    if i in ['(C,(A,B));','((A,B),C);','(C,(B,A));','((B,A),C);']:
        dic_N['(C,(A,B));']+=1

    if i in ['(B,(A,C));','((A,C),B);','(B,(C,A));','((C,A),B);']:
        dic_N['(B,(A,C));']+=1

    if i in ['(A,(B,C));','((B,C),A);','(A,(C,B));','((C,B),A);']:
        dic_N['(A,(B,C));']+=1


print('Simphy_N','Species Tree: (A:15,(B:5,C:5):10);   ',dic_N)

#print('Simphy_2N','Species Tree: (A:0.075,(B:0.025,C:0.025):0.05); ',dic_2N)

print('Dupcoal','Species Tree: (A:1.5,(B:0.5,C:0.5):1.0);',dic_dupcoal)