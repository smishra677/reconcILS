import sys
sys.path.append("../../")
sys.path.append("../")
import subprocess
from reconcILS import *
from utils_reconcILS import *
import os
import argparse


def read_trees(i,folder):
        gene_tre= open(folder+'/rep_'+str(i)+'.tre')
        tr =gene_tre.read().strip().split('\n')
        gene_tre.close()
        return str(tr[0])
def parse1():
    parser = argparse.ArgumentParser(description="IQTree on Simphy and dupcoal")
    parser.add_argument('--simphy', type=str, help="Simphy output folder")
    parser.add_argument('--dupcoal', type=str, help="dupcoal output folder")
    parser.add_argument('--species', type=str, help="Number of Species")
    
    args= parser.parse_args()
    return(args)


parser =parse1()

species=40

if not parser.simphy:
    gene_folder_Dupcoal='./dupcoal_40_just_ILS'

    gene_folder_SimPhy='./SimPhy_outfiles_40_just_ILS'



output_dupcoal= open('./IQTree/IQTree_Dupcoal_'+str(species)+'_scaled_5/dupcoal_tree_list.txt','w+')
output_SimPhy= open('./IQTree/IQTree_SimPhy_'+str(species)+'_scaled_5/simphy_tree_list.txt','w+')

for replicate_ in range(1000):

                        for path_ in [0,1]:
                            if path_ ==0:


                                    red= readWrite.readWrite()
                                    tree= str(open('./'+gene_folder_SimPhy+'/1/g_trees'+str(replicate_+1).zfill(4)+'.trees').read())
                                    tree= tree.replace('e-', '0')
                                    tr=red.parse(tree)
                                    
                                    output_SimPhy.write(tr.to_newick()+'\n')
                                    continue
                                   


                            else:
                                try:
                                    tree= str(read_trees(replicate_,os.path.join('./', gene_folder_Dupcoal)))
                                    tree  = tree.replace('e-', '0')
                                    tr=red.parse(tree)
                                    output_dupcoal.write(tr.to_newick()+'\n')
                                    continue

                                   

                                except:
                                    continue



            
        


os.chdir('./IQTree/IQTree_Dupcoal_40')

subprocess.run(['iqtree2', '-t', './species_40_without_branch_length.tre', '--gcf', f'./dupcoal_tree_list.txt', '--prefix', 'concord'])

os.chdir('../..')

os.chdir('./IQTree/IQTree_SimPhy_40')

subprocess.run(['iqtree2', '-t', './species_40_without_branch_length.tre', '--gcf', f'./simphy_tree_list.txt', '--prefix', 'concord'])

os.chdir('../..')
