library(ape)

va <- rtree(n = 40, rooted = TRUE, 
            tip.label = c("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", 
                          "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", 
                          "Y", "Z", "AA", "AB", "AC", "AD", "AE", "AF", "AG", "AH", 
                          "AI", "AJ", "AK", "AL", "AM", "AN"))


ultrametric_tree <- compute.brlen(va, method = "Grafen")


topology_with_branch_lengths <- write.tree(ultrametric_tree)


cat(topology_with_branch_lengths)
